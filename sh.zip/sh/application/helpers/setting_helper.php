<?php

function setting($key){
    $CI =& get_instance();
    $query=$CI->db->query("SELECT `value` FROM `settings` WHERE `key`="."'$key'");
    return $query->row()->value;
}

function dropdown($table,$atrr1,$atrr2){
    $CI =& get_instance();
    return $CI->db->query("SELECT `$atrr1`,`$atrr2` FROM `$table`")->result();
}


/*function userPerm($key){
    $CI =& get_instance();
    $role = $CI->session->role;
    return $CI->db->query("SELECT * FROM `permission_role` inner join `permissions` on `permission_id` where `role_id` = $role ")->result();
}*/

function userPerm($key, $role){
    $CI =& get_instance();
//    SELECT * FROM `permission_role` inner join `permissions` on `permission_role`.`permission_id` =`permissions`.`id` where `permissions`.`key`='car_category'
    $q = $CI->db->query("SELECT * FROM `permission_role` inner join `permissions` on `permission_role`.`permission_id` = `permissions`.`id`  where `permission_role`.`role_id` = $role and `permissions`.`key`= '".$key."'")->result();
    if (count($q)){
        return true;
    }else{
        return false;
    }
}

