<?php
defined('BASEPATH') OR exit('No direct script access allowed');




$route['default_controller'] = 'home/index';
$route['car/(:num)'] = 'home/car_id/$1';
$route['cars'] = 'home/cars';
$route['categories'] = 'home/categories';
$route['post/(:num)'] = 'home/post_id/$1';
$route['posts'] = 'home/posts';
$route['contact/save'] = 'contact/save_contact';
$route['contact'] = 'home/contactPage';
$route['about'] = 'home/aboutPage';
$route['admin'] = 'dashboard';
$route['logout'] = 'login/logout';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['register/save'] = 'Register/doRegister';


/*CAR CATEGORY*/

$route['admin/car_category'] = 'Car_category/index';
$route['admin/car_category/add'] = 'Car_category/add';
$route['admin/car_category/edit/(:num)'] = 'Car_category/edit/$1';
$route['admin/car_category/remove/(:num)'] = 'Car_category/remove/$1';


/*CAR*/

$route['admin/car'] = 'Car/index';
$route['admin/car/add'] = 'Car/add';
$route['admin/car/edit/(:num)'] = 'Car/edit/$1';
$route['admin/car/remove/(:num)'] = 'Car/remove/$1';


/*CATEGORY*/

$route['admin/category'] = 'category/index';
$route['admin/category/add'] = 'category/add';
$route['admin/category/edit/(:num)'] = 'category/edit/$1';
$route['admin/category/remove/(:num)'] = 'category/remove/$1';

/*home_about_u*/

$route['admin/home_about_u'] = 'home_about_u/index';
$route['admin/home_about_u/add'] = 'home_about_u/add';
$route['admin/home_about_u/edit/(:num)'] = 'home_about_u/edit/$1';
$route['admin/home_about_u/remove/(:num)'] = 'home_about_u/remove/$1';

/*Food Menus*/

$route['admin/food_menu'] = 'food_menu/index';
$route['admin/food_menu/add'] = 'food_menu/add';
$route['admin/food_menu/edit/(:num)'] = 'food_menu/edit/$1';
$route['admin/food_menu/remove/(:num)'] = 'food_menu/remove/$1';


/*newsletter*/

$route['admin/newsletter'] = 'newsletter/index';
$route['admin/newsletter/add'] = 'newsletter/add';
$route['admin/newsletter/remove/(:num)'] = 'newsletter/remove/$1';


/*Post*/

$route['admin/post'] = 'post/index';
$route['admin/post/add'] = 'post/add';
$route['admin/post/edit/(:num)'] = 'post/edit/$1';
$route['admin/post/remove/(:num)'] = 'post/remove/$1';


/*Region*/

$route['admin/region'] = 'region/index';
$route['admin/region/add'] = 'region/add';
$route['admin/region/edit/(:num)'] = 'region/edit/$1';
$route['admin/region/remove/(:num)'] = 'region/remove/$1';


/*Slider*/

$route['admin/slider'] = 'slider/index';
$route['admin/slider/add'] = 'slider/add';
$route['admin/slider/edit/(:num)'] = 'slider/edit/$1';
$route['admin/slider/remove/(:num)'] = 'slider/remove/$1';


/*User*/

$route['admin/user'] = 'user/index';
$route['admin/user/add'] = 'user/add';
$route['admin/user/edit/(:num)'] = 'user/edit/$1';
$route['admin/user/remove/(:num)'] = 'user/remove/$1';

/*Why Us*/

$route['admin/why_choose_u'] = 'why_choose_u/index';
$route['admin/why_choose_u/add'] = 'why_choose_u/add';
$route['admin/why_choose_u/edit/(:num)'] = 'why_choose_u/edit/$1';
$route['admin/why_choose_u/remove/(:num)'] = 'why_choose_u/remove/$1';


/*testimonial*/

$route['admin/testimonial'] = 'testimonial/index';
$route['admin/testimonial/add'] = 'testimonial/add';
$route['admin/testimonial/edit/(:num)'] = 'testimonial/edit/$1';
$route['admin/testimonial/remove/(:num)'] = 'testimonial/remove/$1';


/*Role*/

$route['admin/role'] = 'role/index';
$route['admin/role/add'] = 'role/add';
$route['admin/role/edit/(:num)'] = 'role/edit/$1';
$route['admin/role/remove/(:num)'] = 'role/remove/$1';


/*permission*/

$route['admin/permission'] = 'permission/index';
$route['admin/permission/add'] = 'permission/add';
$route['admin/permission/edit/(:num)'] = 'permission/edit/$1';
$route['admin/permission/remove/(:num)'] = 'permission/remove/$1';



/*Role Permession*/

$route['admin/permission_role'] = 'permission_role/index';
$route['admin/permission_role/add'] = 'permission_role/add';
$route['admin/permission_role/edit/(:num)'] = 'permission_role/edit/$1';
$route['admin/permission_role/remove/(:num)'] = 'permission_role/remove/$1';


/*Setting*/

$route['admin/setting'] = 'setting/index';
$route['admin/setting/add'] = 'setting/add';
$route['admin/setting/edit/(:num)'] = 'setting/edit/$1';
$route['admin/setting/remove/(:num)'] = 'setting/remove/$1';

/*Contact*/

$route['admin/contact'] = 'contact/index';
$route['admin/contact/add'] = 'contact/add';
$route['admin/contact/edit/(:num)'] = 'contact/edit/$1';
$route['admin/contact/remove/(:num)'] = 'contact/remove/$1';




$route['newsletter/save'] = 'newsletter/add';







//contact
//about
//car