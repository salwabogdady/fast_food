<?php


class Contact extends CI_Controller
{
    function __construct()
    {
        parent::__construct();

        /*if ( ! $this->session->userdata('logged_in'))
        {
            redirect('login');
        }*/


        $this->load->helper(array('form', 'url'));

        $this->load->library('form_validation');
        $this->load->model('Contact_model');


    }

    public function save_contact()
    {

        $data['name'] = $this->input->post('name');
        $data['email'] = $this->input->post('email');
        $data['message'] = $this->input->post('message');
        $this->Contact_model->save_contact($data);
        redirect('contact');


    }




    /*HERE*/

    function index()
    {
        $data['contacts'] = $this->Contact_model->get_all_contacts();

        $data['_view'] = 'contact/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new contact
     */
    function add()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('key','Key','required');
        $this->form_validation->set_rules('value','Value','required');

        if($this->form_validation->run())
        {
            $params = array(
                'key' => $this->input->post('key'),
                'value' => $this->input->post('value'),
            );

            $contact_id = $this->Contact_model->add_contact($params);
            redirect('admin/contact/');
        }
        else
        {
            $data['_view'] = 'contact/add';
            $this->load->view('layouts/main',$data);
        }
    }

    /*
     * Editing a contact
     */
    function edit($id)
    {
        // check if the contact exists before trying to edit it
        $data['contact'] = $this->Contact_model->get_contact($id);

        if(isset($data['contact']['id']))
        {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('key','Key','required');
            $this->form_validation->set_rules('value','Value','required');

            if($this->form_validation->run())
            {
                $params = array(
                    'key' => $this->input->post('key'),
                    'value' => $this->input->post('value'),
                );

                $this->Contact_model->update_contact($id,$params);
                redirect('admin/contact/');
            }
            else
            {
                $data['_view'] = 'contact/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The contact you are trying to edit does not exist.');
    }

    /*
     * Deleting contact
     */
    function remove($id)
    {
        $contact = $this->Contact_model->get_contact($id);

        // check if the contact exists before trying to delete it
        if(isset($contact['id']))
        {
            $this->Contact_model->delete_contact($id);
            redirect('admin/contact/');
        }
        else
            show_error('The contact you are trying to delete does not exist.');
    }
}