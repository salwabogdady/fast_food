<?php


class Home extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('MainModel');
    }

    public function index()
    {
        $data = [];
        $data['slider'] = $this->MainModel->get_slider();
        $data['setting'] = $this->MainModel->get_setting();
        $data['home_about_us'] = $this->MainModel->home_about_us();
        $data['cars'] = $this->MainModel->get_cars();
        $data['why_choose_us'] = $this->MainModel->get_why_us();
        $data['testimonials'] = $this->MainModel->get_testimonials();
        $data['latest_posts'] = $this->MainModel->get_latest_posts();
        $data['latest_post'] = $this->MainModel->get_latest_post();

        //$this->MainModel->get_user_by_id($latest_post->author_id);
        // var_dump($this->MainModel->get_user_by_id(1)->name);
        // die();

        $this->load->view('front/home', $data);
        $this->load->view('front/parts/footer');
    }

    public function car_id($id)
    {

        $car = $this->MainModel->get_car_data($id);
        $owner = $this->MainModel->get_user_by_id($car->owner);
        $category = $this->MainModel->get_car_category_by_id($car->category)->name;
        $region = $this->MainModel->get_region_by_id($car->region);
        $menus = $this->MainModel->get_car_menus_by_id($id);

        $data['car']=$car;
        $data['car']->owner=$owner;
        $data['car']->category=$category;
        $data['car']->region=$region;

        $data['car']->menus=$menus;



        $this->load->view('front/car',$data);

    }

    public function cars()
    {
        $cars = $this->MainModel->get_cars();
        $new_cars=[];
        foreach ($cars as $car){
            $car['category_name'] = $this->MainModel->get_car_category_by_id($car['category'])->name;
            $new_cars[]=$car;
        }

        $this->load->view('front/cars', ['cars'=>$new_cars]);
    }


    public function contactPage()
    {
        $this->load->view('front/contact');
    }

    public function aboutPage(){
        $this->load->view('front/about');
    }

    public function categories(){
        $categories = $this->MainModel->get_categories();

        $this->load->view('front/blogCat', ['categories'=>$categories]);
    }

    public function post_id($id){
        $post = $this->MainModel->get_post($id);
        $author = $this->MainModel->get_user_by_id($post->author_id);
        $category = $this->MainModel->get_category_by_id($post->category_id)->name;
        

        $data['post']=$post;
        $data['post']->author=$author;
        $data['post']->category=$category;

        $this->load->view('front/singlePost', $data);
    }
    



    public function posts(){
        $posts = $this->MainModel->get_posts();
        $this->load->view('front/multiPosts', ['posts'=>$posts]);
    }


}