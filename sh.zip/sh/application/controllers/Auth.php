<?php


class Auth extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        //$this->load->model('');
    }

    function login(){
        $this->load->view('auth/login');
    }

    function register(){
        $this->load->view('auth/register');
    }

    public function sign_up(){

        $this->load->library('form_validation');

        $this->form_validation->set_rules('password','Password','required');
        $this->form_validation->set_rules('name','Name','required');
        $this->form_validation->set_rules('email','Email','required');

        if($this->form_validation->run())
        {
            $params = array(
                'password' => sha1($this->input->post('password')),
                'role_id' => 2,
                'name' => $this->input->post('name'),
                'email' => $this->input->post('email'),
            );
            $this->load->model('User_model');
            $user_id = $this->User_model->add_user($params);
            redirect('admin/');
        }
    }


}