<?php


class MainModel extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    public function get_slider()
    {

        return $this->db->query('SELECT * FROM `slider` ORDER BY ID DESC LIMIT 1')->row();
    }

    public function get_setting()
    {

        return $this->db->query('SELECT * FROM `settings` ORDER BY ID')->result_array();
    }

    public function home_about_us()
    {

        return $this->db->query('SELECT * FROM `home_about_us` ORDER BY ID DESC LIMIT 1')->row();
    }


    /*CAR SLUG START*/
    public function get_car_data($id)
    {
        return $this->db->query('SELECT * FROM `cars` WHERE `id` = ' . $id)->row();
    }

    public function get_user_by_id($id)
    {
        return $this->db->query('SELECT * FROM `users` WHERE `id` = ' . $id)->row();
    }

    public function get_region_by_id($id)
    {
        return $this->db->query('SELECT * FROM `regions` WHERE `id` = ' . $id)->row();
    }

    public function get_car_category_by_id($id)
    {
        return $this->db->query('SELECT * FROM `car_category` WHERE `id` = ' . $id)->row();
    }

    public function get_car_menus_by_id($id)
    {
        return $this->db->query('SELECT * FROM `food_menus` WHERE `car` = ' . $id)->result_array();
    }

    /*CAR SLUG END*/
    /*CARS SLUG START*/
    public function get_cars()
    {
        $cars = $this->db->query('SELECT * FROM `cars`')->result_array();
        $news = [];
        $i = 0;
        foreach ($cars as $car) {
            $news[$i] = $car;
            $news[$i]['region_name'] = $this->get_region_by_id($car['region'])->name;
            $i++;
        }
        return $news;
    }


    /*CARS SLUG END*/

    public function get_why_us()
    {
        return $this->db->query('SELECT * FROM `why_choose_us` ORDER BY ID DESC LIMIT 1')->row();
    }

    public function get_testimonials()
    {
        return $tes = $this->db->query('SELECT * FROM `testimonials`')->result();

    }

    public function get_latest_post()
    {
        return $latest_post = $this->db->query('SELECT * FROM `posts` ORDER BY id DESC LIMIT 1')->row();
    }

    public function get_latest_posts()
    {
        return $latest_post = $this->db->query('SELECT * FROM `posts` WHERE id != (SELECT MAX(id) FROM posts)')->result();
    }
    // blog
    public function get_posts()
    {
        return $latest_post = $this->db->query('SELECT * FROM `posts` ')->result();
    }

    public function get_post($id)
    {
        return $post = $this->db->query('SELECT * FROM `posts` WHERE `id` = ' . $id)->row();
    }

    public function get_category_by_id($id)
    {
        return $this->db->query('SELECT * FROM `categories` WHERE `id` = ' . $id)->row();
    }
}