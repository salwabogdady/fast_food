<?php


class Contact_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    public function save_contact($params){
        $this->db->insert('contacts',$params);
    }



    /*
     * Get setting by id
     */
    function get_contact($id)
    {
        return $this->db->get_where('contacts',array('id'=>$id))->row_array();
    }

    /*
     * Get all contacts
     */
    function get_all_contacts()
    {
        $this->db->order_by('id', 'desc');
        return $this->db->get('contacts')->result_array();
    }

    /*
     * function to add new setting
     */
    function add_setting($params)
    {
        $this->db->insert('contacts',$params);
        return $this->db->insert_id();
    }

    /*
     * function to update setting
     */
    function update_setting($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('contacts',$params);
    }

    /*
     * function to delete setting
     */
    function delete_contact($id)
    {
        return $this->db->delete('contacts',array('id'=>$id));
    }

}