<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Food Menu Edit</h3>
            </div>
			<?php echo form_open_multipart('admin/food_menu/edit/'.$food_menu['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="title" class="control-label"><span class="text-danger">*</span>Title</label>
						<div class="form-group">
							<input type="text" name="title" value="<?php echo ($this->input->post('title') ? $this->input->post('title') : $food_menu['title']); ?>" class="form-control" id="title" />
							<span class="text-danger"><?php echo form_error('title');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="car" class="control-label"><span class="text-danger">*</span>Car</label>
						<div class="form-group">
                            <select name="car" class="form-control">
                                <?php foreach ($cars as $own){
                                    ?>
                                    <option <?php if($food_menu['car']==$own->id) {echo "selected";} ?> value="<?=$own->id?>"><?=$own->title?></option>
                                <?php } ?>
                            </select>
							<span class="text-danger"><?php echo form_error('car');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="description" class="control-label"><span class="text-danger">*</span>Description</label>
						<div class="form-group">
							<textarea name="description" class="form-control" id="description"><?php echo ($this->input->post('description') ? $this->input->post('description') : $food_menu['description']); ?></textarea>
							<span class="text-danger"><?php echo form_error('description');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="images" class="control-label"><span class="text-danger">*</span>Images</label>
						<div class="form-group">
                            <input type="file" name="image" class="form-control" id="image"/>
							<span class="text-danger"><?php echo form_error('images');?></span>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>