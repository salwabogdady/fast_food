<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Post Add</h3>
            </div>
            <?php echo form_open_multipart('admin/post/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">

					<div class="col-md-6">
						<label for="category_id" class="control-label"><span class="text-danger">*</span>Category</label>
						<div class="form-group">
							<select name="category_id" class="form-control">
								<option value="">Select Category</option>
								<?php 
								foreach($all_categories as $category)
								{
									$selected = ($category['id'] == $this->input->post('category_id')) ? ' selected="selected"' : "";

									echo '<option value="'.$category['id'].'" '.$selected.'>'.$category['name'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('category_id');?></span>
						</div>
					</div>

					<div class="col-md-6">
						<label for="title" class="control-label"><span class="text-danger">*</span>Title</label>
						<div class="form-group">
							<input type="text" name="title" value="<?php echo $this->input->post('title'); ?>" class="form-control" id="title" />
							<span class="text-danger"><?php echo form_error('title');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="seo_title" class="control-label">Seo Title</label>
						<div class="form-group">
							<input type="text" name="seo_title" value="<?php echo $this->input->post('seo_title'); ?>" class="form-control" id="seo_title" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="image" class="control-label"><span class="text-danger">*</span>Image</label>
						<div class="form-group">
							<input type="file" name="image" value="<?php echo $this->input->post('image'); ?>" class="form-control" id="image" />
							<span class="text-danger"><?php echo form_error('image');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="slug" class="control-label"><span class="text-danger">*</span>Slug</label>
						<div class="form-group">
							<input type="text" name="slug" value="<?php echo $this->input->post('slug'); ?>" class="form-control" id="slug" />
							<span class="text-danger"><?php echo form_error('slug');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="status" class="control-label"><span class="text-danger">*</span>Status</label>
						<div class="form-group">
                            <select name="status" class="form-control">


                                    <option value="1">published</option>
                                    <option value="2">drafted</option>
                                    <option value="3">pend</option>

                            </select>
							<span class="text-danger"><?php echo form_error('status');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="excerpt" class="control-label"><span class="text-danger">*</span>Excerpt</label>
						<div class="form-group">
							<textarea name="excerpt" class="form-control" id="excerpt"><?php echo $this->input->post('excerpt'); ?></textarea>
							<span class="text-danger"><?php echo form_error('excerpt');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="body" class="control-label"><span class="text-danger">*</span>Body</label>
						<div class="form-group">
							<textarea name="body" class="form-control" id="body"><?php echo $this->input->post('body'); ?></textarea>
							<span class="text-danger"><?php echo form_error('body');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="meta_description" class="control-label">Meta Description</label>
						<div class="form-group">
							<textarea name="meta_description" class="form-control" id="meta_description"><?php echo $this->input->post('meta_description'); ?></textarea>
						</div>
					</div>
					<div class="col-md-6">
						<label for="meta_keywords" class="control-label">Meta Keywords</label>
						<div class="form-group">
							<textarea name="meta_keywords" class="form-control" id="meta_keywords"><?php echo $this->input->post('meta_keywords'); ?></textarea>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>