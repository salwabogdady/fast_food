<?php

$this->load->view('front/parts/header');

?>

    <!-- section breadcrumbs-->
    <section class="breadcrumbs breadcrumbs-section bg-image overlay-dark-04 context-dark" style="background-image: url( <?=base_url('assets')?>/images/breadcrumbs-bg.jpg)">
        <div class="container text-center">
            <h2 class="h2-small">من نحن</h2>
            <!-- Breadcrumb-->
            <ul class="breadcrumb d-inline-flex justify-content-center">
                <li class="breadcrumb-item"><a class="breadcrumb-link" href="<?php base_url('')?>">الرئيسيه</a></li>
                <li class="breadcrumb-item"><span class="breadcrumb-text breadcrumb-active">من نحن</span></li>
            </ul>
        </div>
    </section>
    <section class="section section-md bg-transparent">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="text-center"><img src=" <?=base_url('assets')?>/images/icon-7-53x56.png" alt="" width="53" height="56"/>
                        <h4 class="text-warning font-cursive font-weight-normal text-capitalize">قصتنا</h4>
                        <h4>نحن نتمير بخدمة عملائنا علي مدار اليوم (خلال ال 24 ساعة).</h4>
                    </div>
                    <div class="row row-30">
                        <div class="col-md-6">
                            <p>يتضمن من خلال عربات الطعام تقديم افضل ما لديهم للحفاظ علي راحة العملاء.</p>
                        </div>
                        <div class="col-md-6">
                            <p>يوجد لدينا التغليف الجيد للوجبات المقدمه للحفاظ علي سلامة وصحة عملاءنا.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section section-md bg-transparent">
        <div class="container"><img src=" <?=base_url('assets')?>/images/about-1-1170x537.jpg" alt="" width="1170" height="537"/>
        </div>
    </section>
    <section class="section section-md bg-transparent">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10 col-xl-9 text-center">
                    <h2><img src=" <?=base_url('assets')?>/images/quote-icon.png" alt=""/>
                    </h2>
                    <!-- Quote simple-->
                    <div class="quote quote-simple mt-4">
                        <div class="quote-text">
                            <q>يوجد لدينا جميع انواع الأكلات (المصري _ الصيني _ الياباني _الهندي).</q>
                        </div>
                        <div class="quote-author h6"><img src=" <?=base_url('assets')?>/images/author-name.png" alt=""/>
                            <p>-Salwa hissain</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section section-md bg-transparent">
        <div class="container">
            <div class="row row-30">
                <div class="col-md-6">
                    <div class="row row-30">
                        <div class="col-sm-6 col-md-12"><img src=" <?=base_url('assets')?>/images/about-2-570x428.jpg" alt="" width="570" height="428"/>
                        </div>
                        <div class="col-sm-6 col-md-12"><img src=" <?=base_url('assets')?>/images/about-3-570x428.jpg" alt="" width="570" height="428"/>
                        </div>
                    </div>
                </div>
                <div class="col-md-6"><img src=" <?=base_url('assets')?>/images/about-4-570x885.jpg" alt="" width="570" height="885"/>
                </div>
            </div>
        </div>
    </section>
    <section class="section section-md bg-transparent">
        <div class="container">
            <div class="row row-50 justify-content-center">
                <div class="col-lg-10 col-xl-9">
                    <div class="text-center">
                        <h4 class="text-warning font-cursive font-weight-normal text-capitalize">التركيز علي الجوده</h4>
                        <h4>تفخر Grillparty بتقديم الأطباق الشعبيه !</h4>
                    </div>
                </div>
                <div class="col-lg-10">
                    <div class="row row-30">
                        <div class="col-md-6">
                            <p>خبرة الشيف أعلي دور في أي مطبخ وهذا هو الشخص المسئول عن جميع جوانب المطبخ بجميع موظفين المطبخ وهو المسئول في نهاية المطاف علي نفسه وعلي الموظفين.</p>
                        </div>
                        <div class="col-md-6">
                            <p>يتضمن من خلال موقعنا تقديم الوجبات بأفضل المنتجات الطبيعية.</p>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="row row-30 text-center">
                        <div class="col-sm-6 col-lg-4"><img src=" <?=base_url('assets')?>/images/about-5-370x428.jpg" alt="" width="370" height="428"/>
                        </div>
                        <div class="col-sm-6 col-lg-4"><img src=" <?=base_url('assets')?>/images/about-6-370x428.jpg" alt="" width="370" height="428"/>
                        </div>
                        <div class="col-sm-6 col-lg-4"><img src=" <?=base_url('assets')?>/images/about-7-370x428.jpg" alt="" width="370" height="428"/>
                        </div>
                        <div class="col-12"><a class="btn btn-lg btn-primary" href="<?=base_url('cars')?>">رؤيه السيارات</a></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <div class="section-sm bg-secondary text-center">
                <div class="container">
                    <div class="row row-30 justify-content-center align-items-center">
                        <div class="col-auto col-lg"><img src=" <?=base_url('assets')?>/images/partner-1-87x87.png" alt="" width="87" height="87"/>
                        </div>
                        <div class="col-auto col-lg"><img src=" <?=base_url('assets')?>/images/partner-2-122x71.png" alt="" width="122" height="71"/>
                        </div>
                        <div class="col-auto col-lg"><img src=" <?=base_url('assets')?>/images/partner-3-99x88.png" alt="" width="99" height="88"/>
                        </div>
                        <div class="col-auto col-lg"><img src=" <?=base_url('assets')?>/images/partner-4-130x69.png" alt="" width="130" height="69"/>
                        </div>
                        <div class="col-auto col-lg"><img src=" <?=base_url('assets')?>/images/partner-5-73x82.png" alt="" width="73" height="82"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



<?php

$this->load->view('front/parts/footer');

?>