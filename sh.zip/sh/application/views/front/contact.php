<?php

$this->load->view('front/parts/header');

?>


<!-- section breadcrumbs-->
<section class="breadcrumbs breadcrumbs-section bg-image overlay-dark-04 context-dark" style="background-image: url( <?=base_url('assets')?>/images/breadcrumbs-bg.jpg )">
    <div class="container text-center">
        <h2 class="h2-small">التسجيل</h2>
        <!-- Breadcrumb-->
        <ul class="breadcrumb d-inline-flex justify-content-center">
            <li class="breadcrumb-item"><span class="breadcrumb-text breadcrumb-active">التسجيل</span></li>
            <li class="breadcrumb-item"><a class="breadcrumb-link" href="<?=base_url('')?>">الرئيسيه</a></li>
            
        </ul>
    </div>
</section>
<!-- Contact us-->
<section class="section section-sm bg-primary novi-background context-dark" data-preset='{"title":"Contact Us","category":"contacts","reload":false,"id":"contact-us-3"}'>
    <div class="container text-center">
        <div class="row row-40">
            <div class="col-sm-6 col-lg-4">
                <!-- Icon box Classic-->
                <div class="blurb blurb-creative"><img class="blurb-creative-icon" src="<?=base_url('assets')?>/images/icon-1-103x92.png" alt="" width="103" height="92"/>
                    <h6 class="blurb-creative-title">العنوان</h6>
                    <p><?= setting('address') ?></p>
                </div>
            </div>
            <!-- <div class="col-sm-6 col-lg-3"> -->
                <!-- Icon box Classic-->
                <!-- <div class="blurb blurb-creative"><img class="blurb-creative-icon" src="<?=base_url('assets')?>/images/icon-2-103x103.png" alt="" width="103" height="103"/>
                    <h6 class="blurb-creative-title">Opening hours</h6>
                    <p>Mon - Sun<br>8am - 9pm</p>
                </div> -->
            <!-- </div> -->
            <div class="col-sm-6 col-lg-4">
                <!-- Icon box Classic-->
                <div class="blurb blurb-creative"><img class="blurb-creative-icon" src="<?=base_url('assets')?>/images/icon-3-98x99.png" alt="" width="98" height="99"/>
                    <h6 class="blurb-creative-title">رقم الموبايل</h6>
                    <p><a href="tel:<?= setting('phone') ?>"><?= setting('phone') ?></a></p>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4">
                <!-- Icon box Classic-->
                <div class="blurb blurb-creative"><img class="blurb-creative-icon" src="<?=base_url('assets')?>/images/icon-4-103x97.png" alt="" width="103" height="97"/>
                    <h6 class="blurb-creative-title">البريد الالكتروني</h6>
                    <p><a href="mailto:<?= setting('email') ?>"><?= setting('email') ?></a></p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- section map-->
<section class="section section-md">
    <div class="container">
        <!-- Google map-->
        <div class="google-map" data-settings='{"center":{"lat":40.715847,"lng":-73.999925},"zoom":12,"markers":{"park":{"position":"Columbus Park, Baxter Street, New York, United State","html":"Columbus park"}},"styles":[{"featureType":"administrative.country","elementType":"geometry","stylers":[{"visibility":"simplified"},{"hue":"#ff0000"}]}]}' id="map1"></div>
    </div>
</section>
<!-- service contact us-->
<section class="section-md bg-primary bg-image context-dark" style="background-image: url(<?=base_url('assets')?>/images/bg-pattern-2.png)">
    <div class="container text-center">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <h3 class="text-warning">هل لديك سؤال</h3>
                <h2 class="mt-1">ابق علي اتصال </h2>
                <!-- RD Mailform-->
                <form class=" text-left row row-15 gutters-16" data-form-output="form-output-global" data-form-type="contact" method="post" action="<?=base_url('contact/save')?>">
                    <div class="col-md-6">
                        <div class="form-group">
                            <input class="form-control" id="contact-name" type="text" name="name" data-constraints="@Required" placeholder="الاسم">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <input class="form-control" id="contact-email" type="email" name="email" data-constraints="@Email @Required" placeholder="الايميل">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <textarea class="form-control" id="contact-message" name="message" data-constraints="@Required" placeholder="الرساله" style="min-height: 120px"></textarea>
                        </div>
                    </div>
                    <div class="col-md-12 text-center">
                        <button class="btn btn-secondary" type="submit">ارسال رساله</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>



<?php
$this->load->view('front/parts/footer');

?>
