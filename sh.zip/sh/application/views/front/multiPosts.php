<?php
$this->load->view('front/parts/header');

// var_dump($posts);
// die();

?>


<div class="blog-section paddingTB60 ">
<div class="container">
	<div class="row">
		<div class="site-heading text-center" style="width: 100%;">
						<h3 style="font-family: 'Lemonada', cursive;font-weight: 100;text-align: center">المدونه</h3>
						
						<div class="border"></div>
					</div>
	</div>
	<div class="row text-center">

        <?php 
            foreach ($posts as $post) {
                ?>
                 <div class="col-sm-6 col-md-4">
                        <div class="blog-box">
                            <div class="blog-box-image">
                                <img src="<?=base_url('').$post->image?>" class="img-responsive" alt="">
                            </div>
                            <div class="blog-box-content">
                                <h4><a href="<?=base_url('post/').$post->id?>"><?=$post->title?></a></h4>
                                <p>
                                <?=substr($post->body, 0 , 150)?>
                                </p>
                                <a href="<?=base_url('post/').$post->id?>" class="btn btn-md btn-secondary  "style="font-family: 'Lemonada', cursive;font-weight: 100;text-align: center">المزيد</a>
                            </div>
                        </div>
                    </div>
                    <!-- End Col -->	
                <?php
            }
        ?>
	      
    </div>
</div>
</div>
<style>
    
    /* Blog-CSS */
    .blog-box {
        padding: 0 0px;
        transition: .5s;
        border: 1px solid #e2e2e2;
        margin-bottom: 30px;
    }
    .blog-box-content h4 a {
        font-size: 20px;
        padding: 0px 0 0px;
        text-transform: uppercase;
        color:#2b2b2b;
        text-decoration:none;
        
    }
    .blog-box-content h4:hover {
        color:#000;
        text-decoration:none;
        
    }

    .blog-box-content {
    padding: 0 20px 20px;
    }
    .blog-box-text h4 a {
        color: #333;
    } 
</style>

<?php
$this->load->view('front/parts/footer');
?>
