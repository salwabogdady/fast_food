<!DOCTYPE html>
<html lang="ar">
<head>
    <title>Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta property="og:title" content="Template Monster Admin Template">
    <meta property="og:description"
          content="brevis, barbatus clabulares aliquando convertam de dexter, peritus capio. devatio clemens habitio est.">
    <meta property="og:image" content="https://digipunk.netii.net/images/radar.gif">
    <meta property="og:url" content="https://digipunk.netii.net">
    <script src="<?php echo site_url('assets/'); ?>/js/3ts2ksMwXvKRuG480KNifJ2_JNM.js"></script>
    <link rel="icon" href="<?php echo site_url('assets/'); ?>/images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo site_url('assets/'); ?>/css/base.css">
    <script src="<?php echo site_url('assets/'); ?>/js/core.min.js"></script>
    <script src="<?php echo site_url('assets/'); ?>/js/script.min.js"></script>
    <!-- google arabic font  -->
    <link href="https://fonts.googleapis.com/css?family=Lemonada&display=swap" rel="stylesheet">    
    <!--  -->
</head>
<body>
<div class="preloader">
    <div class="preloader-body">
        <div class="cssload-container">
            <div class="cssload-speeding-wheel"></div>
        </div>
    </div>
</div>
<div class="page">
    <!--RD Navbar-->
    <header class="section rd-navbar-wrap" dir="rtl"
            data-preset='{"title":"Navbar Default","category":"header","reload":true,"id":"navbar-default"}'>
        <nav class="rd-navbar">
            <div class="navbar-container">
                <div class="navbar-cell">
                    <div class="navbar-panel">
                        <button class="navbar-switch fa-bars novi-icon"
                                data-multi-switch='{"targets":".rd-navbar","scope":".rd-navbar","isolate":"[data-multi-switch]"}'></button>
                        <div class="navbar-logo"><a class="navbar-logo-link" href="<?= base_url('/') ?>"><img
                                        class="navbar-logo-default"
                                        src="<?= base_url(''); ?>/assets/images/logo-default-163x82.png"
                                        alt="GrillParty" width="163" height="82"/><img class="navbar-logo-inverse"
                                                                                       src="<?php echo site_url('assets/'); ?>/images/logo-default-163x82.png"
                                                                                       alt="GrillParty" width="163"
                                                                                       height="82"/></a></div>
                    </div>
                </div>
                <div class="navbar-cell navbar-spacer"></div>
                <div class="navbar-cell navbar-sidebar">
                    <ul class="navbar-navigation rd-navbar-nav">
                        <li class="navbar-navigation-root-item active"><a class="navbar-navigation-root-link"
                                                                          href="<?= base_url('') ?>">الرئيسيه</a></li>
                        <li class="navbar-navigation-root-item"><a class="navbar-navigation-root-link"
                                                                   href="<?= base_url('cars') ?>">العربيات</a></li>
                        <li class="navbar-navigation-root-item"><a class="navbar-navigation-root-link"
                                                                   href="<?= base_url('auth/register') ?>">تسجيل جديد</a></li>
                        <li class="navbar-navigation-root-item"><a class="navbar-navigation-root-link"
                                                                   href="<?= base_url('auth/login') ?>">دخول</a></li>                                           
                        <li class="navbar-navigation-root-item"><a class="navbar-navigation-root-link"
                                                                   href="<?= base_url('about') ?>">من نحن</a></li>
                        <li class="navbar-navigation-root-item"><a class="navbar-navigation-root-link"
                                                                   href="<?= base_url('contact') ?>">اتصل بنا</a></li>
                    </ul>
                </div>

            </div>
        </nav>
    </header>