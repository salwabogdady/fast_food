<!-- Footer event-->
<footer class="section footer footer-default bg-transparent novi-background" data-preset='{"title":"Footer Minimal","category":"footer","reload":true,"id":"footer-minimal"}'>
    <div class="footer-default-top">
        <div class="container">
            <div class="row row-30 justify-content-lg-between">
                <div class="col-md-3 text-center text-md-left">
                    <!-- Logo-->
                    <div class="logo"><a class="logo-link" href="index.html"><img class="logo-image-default" src="<?=base_url('');?>/assets/images/logo-default-163x82.png" alt="GrillParty" width="163" height="82"/><img class="logo-image-inverse" src="<?=base_url('')?>assets/images/logo-default-163x82.png" alt="" width="163" height="82"/></a></div>
                </div>
                <div class="col-6 col-sm-4 col-md-3 text-center text-sm-left">
                    <ul class="list-footer">
                        <li class="list-item">2605 Scheuvront Drive,<br>New York, NY 99515</li>
                    </ul>
                </div>
                <div class="col-6 col-sm-4 col-md-2 text-center text-sm-left">
                    <ul class="list-footer">
                        <li class="list-item"><a class="list-link" href="<?=base_url('about')?>">من نحن</a></li>
                        <li class="list-item"><a class="list-link" href="<?=base_url('contacts')?>">اتصل بنا</a></li>
                    </ul>
                </div>
                <div class="col-12 col-sm-4 col-lg-4 text-center text-sm-left">
                    <ul class="list-footer">
                        <li class="list-item"><a class="list-link" href="mailto:#">info@demolink.org</a></li>
                        <li class="list-item"><a class="list-link" href="tel:#">+ 166 900 891</a></li>
                    </ul>
                    <div class="icon-social-list group-10 d-flex justify-content-center justify-content-sm-start"><a class="icon icon-circle icon-secondary fa-facebook novi-icon" href="#"></a><a class="icon icon-circle icon-secondary fa-twitter novi-icon" href="#"></a><a class="icon icon-circle icon-secondary fa-instagram novi-icon" href="#"></a></div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="divider divider-xl divider-200"></div>
    </div>
    <div class="footer-default-bottom">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center text-md-left">
                    <!-- Copyright-->
                    <p class="rights"><span>&copy; 2020&nbsp;</span><span></span><span>. جميع الحقوق محفوظه&nbsp;</span></p>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Modal-->
<div class="modal fade" id="modal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content context-dark bg-primary">
            <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span class="mdi mdi-close-circle" aria-hidden="true"></span></button>
            <div class="section-md text-center">
                <div class="row row-30 justify-content-center">
                    <div class="col-11 col-lg-9">
                        <h3 class="text-warning">Subscribe</h3>
                    </div>
                    <div class="col-11 col-lg-9">
                        <h4>Join our Newsletter list to get all the latest offers and discounts</h4>
                    </div>
                    <div class="col-11 col-lg-8">
                        <form class="rd-mailform form-inline justify-content-center novi-disabled" data-form-output="form-output-global" data-form-type="subscribe" method="post" action="components/rd-mailform/rd-mailform.php">
                            <div class="form-inline-group">
                                <input class="form-control" type="email" name="email" placeholder="الايميل" data-constraints="@Email @Required">
                            </div>
                            <button class="btn btn-secondary" type="submit">اشترك معنا</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<div class="form-output snackbar snackbar-dark" id="form-output-global"> </div>


<!--LIVEDEMO_00 -->


</body>

</html>




