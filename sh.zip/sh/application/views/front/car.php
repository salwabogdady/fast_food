<?php

$this->load->view('front/parts/header');

?>

<section class="container" style="margin-top: 75px">

    <div class="row active-with-click">

       
        <?php 
            if($car->menus){

            
            foreach($car->menus as $m){
                // var_dump($m);
                // die();
        ?>
            
            <div class="col-md-4 col-sm-6 col-xs-12">
                <article class="material-card Orange">
                    <h2>
                        <span><?=$m['title']?></span><br><br>

                    </h2>
                    <strong>القسم :</strong><small><?=$car->category?></small><br>
                    <strong>رقم الموبايل :</strong><small><?=$car->phone?></small><br>
                    <div class="mc-content">
                        <div class="img-container">
                            <img class="img-responsive" src="<?=base_url($m['image'])?>">
                        </div>
                        <div class="mc-description">
                            <?=$m['description']?>
                        </div>
                    </div>
                    <a class="mc-btn-action">

                    </a>

                </article>
            </div>

        <?php }
        }else{
        ?>
        
        <h3 style="text-align: center">لا يوجد بيانات لهذه السياره</h3>
        
        <?php }?>

    </div>
</section>
<?php

$this->load->view('front/parts/footer');

?>