<?php
$this->load->view('front/parts/header');
?>


<section class="container" style="margin-top: 75px">

    <div class="row active-with-click">

<!------ Include the above in your HEAD tag ---------->

        <div class="container" style="text-align:right">
            <div class="row">
                <div class="col-md-10 offset-1">
                    <div class="row mb-2">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="news-title">
                                                <h2><?=$post->title?></h2>
                                            </div>
                                            <div class="news-cats">
                                                <ul class="list-unstyled list-inline mb-1">
                                                    <li class="list-inline-item">
                                                            <i class="fa fa-folder-o text-danger"></i>
                                                            <small><?=$post->category?></small>
                                                    </li>
                                                    
                                                        <li class="list-inline-item">
                                                            <i class="fa fa-user-o text-danger"></i>
                                                            <small><?=$post->author->name?></small>
                                                        </li> 
                                                   
                                                </ul>
                                            </div>
                                            <hr>
                                            <div class="news-image">
                                                <img style="width: 100%" src="<?=base_url('').$post->image?>">
                                                <p class="text-muted "><?=$post->body?></p>
                                            </div>
                                           
                                    
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            
            </div>
        </div>


    </div>
</section>


<?php
$this->load->view('front/parts/footer');
?>
