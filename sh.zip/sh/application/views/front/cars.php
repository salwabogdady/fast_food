<?php

$this->load->view('front/parts/header');

?>
    <!-- Home Menu-->
    <section class="section section-md bg-transparent">
        <div class="container">
            <div class="row row-50">

                <?php foreach ($cars as $car) { ?>


                    <div class="col-xs-6 col-lg-4">
                        <article class="product">
                            <div class="product-figure">
                                <a href="<?= base_url('car/' . $car['id']) ?>"><img class="product-image"
                                                                                    src="<?= base_url('') . $car['image'] ?>"
                                                                                    alt="" width="169"
                                                                                    height="169"/></a>

                            </div>
                            <div class="product-body">
                                <div class="product-title h5"><a
                                            href="<?= base_url('car/' . $car['id']) ?>"><?= $car['title'] ?></a></div>
                                <p class="product-text"><strong>Category:</strong> <?= substr($car['category_name'], 0, 100) ?></p>
                                <p class="product-text"><strong>Description:</strong><?= substr($car['description'], 0, 100) ?></p>
                                <p class="product-text"><strong>Phone: </strong><?= substr($car['phone'], 0, 100) ?></p>
                                <div class="product-price"><span><?= $car['region_name'] ?></span></div>
                            </div>
                        </article>
                    </div>

                <?php } ?>

            </div>
        </div>
    </section>


<?php

$this->load->view('front/parts/footer');

?>