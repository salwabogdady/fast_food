<?php
$this->load->view('front/parts/header');
?>
    <!-- Intro-->
    <section
            class="section section-lg bg-image text-center d-flex align-items-center min-vh-100 novi-background context-dark overlay-dark-04"
            data-preset='{"title":"Intro","category":"intro","reload":false,"id":"intro-10"}'
            style="background-image: url(<?=base_url('/');?>/<?= $slider->image ?>);">
        <div class="container">
            <div class="row justify-content-center novi-disabled">
                <div class="col-md-10 col-lg-8" data-animate='{"class":"fadeInUp"}'>
                    <h3 class="text-secondary"><?= $slider->slug ?></h3>
                    <h1 class="mt-0"><?= $slider->text_2 ?></h1>
                    <div class="offset-md"><a class="btn btn-lg btn-secondary" href="<?=base_url('about')?>">من نحن</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact us-->
    <section class="section section-sm bg-primary novi-background context-dark"
             data-preset='{"title":"Contact Us","category":"contacts","reload":false,"id":"contact-us-3"}'>
        <div class="container text-center">
            <div class="row row-40">
                <div class="col-sm-6 col-lg-4">
                    <!-- Icon box Classic-->
                    <div class="blurb blurb-creative">
                        <img class="blurb-creative-icon" src="<?=base_url() ?>/assets/images/icon-1-103x92.png" alt="" width="103"
                             height="92"/>
                        <h6 class="blurb-creative-title">العنوان</h6>
                        <p><?= setting('address') ?></p>
                    </div>
                </div>
                <!-- <div class="col-sm-6 col-lg-3"> -->
                    <!-- Icon box Classic-->
                    <!-- <div class="blurb blurb-creative"><img class="blurb-creative-icon"
                                                           src="<?=base_url() ?>/assets/images/icon-2-103x103.png" alt="" width="103"
                                                           height="103"/>
                        <h6 class="blurb-creative-title">Opening hours</h6>
                        <p>Mon - Sun<br>8am - 9pm</p>
                    </div> -->
                <!-- </div> -->
                <div class="col-sm-6 col-lg-4">
                    <!-- Icon box Classic-->
                    <div class="blurb blurb-creative"><img class="blurb-creative-icon"
                                                           src="<?=base_url() ?>/assets/images/icon-3-98x99.png" alt="" width="98"
                                                           height="99"/>
                        <h6 class="blurb-creative-title">رقم الموبايل</h6>
                        <p><a href="tel:<?= setting('phone') ?>"><?= setting('phone') ?></a>
                            <!-- <br>
                            <a href="tel:<?= setting('phone') ?>"><?= setting('phone') ?></a></p> -->
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <!-- Icon box Classic-->
                    <div class="blurb blurb-creative"><img class="blurb-creative-icon"
                                                           src="<?=base_url() ?>/assets/images/icon-4-103x97.png" alt=""
                                                           width="103" height="97"/>
                        <h6 class="blurb-creative-title">البريد الالكتروني</h6>
                        <p><a href="mailto:<?= setting('email') ?>"><?= setting('email') ?></a>
                            <!-- <br>
                            <a href="mailto:<?= setting('email') ?>"><?= setting('email') ?></a></p> -->
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Home About-->
    <section class="section section-md bg-white">
        <div class="container">
            <div class="row row-50 justify-content-between">
                <div class="col-lg-6">
                    <div class="text-box-decorate">
                        <div class="decorate-text text-100">Fast<br>Food</div>
                        <h3 class="text-warning">The Best Meals</h3>
                        <h2><?= $home_about_us->title ?></h2>
                    </div>
                    <img class="position-relative" src="<?= base_url() ?>/<?= $home_about_us->image_1 ?>" alt=""
                         width="570" height="458"/>
                </div>
                <div class="col-lg-6 col-xl-5">
                    <!-- Offer box image right-->
                    <div class="offer-box offer-box-image-right">
                        <div class="offer-box-image">
                            <div class="offer-box-image-inner"
                                 style="background-image: url(&quot;<?= base_url() ?>/<?= $home_about_us->image_2 ?>&quot;)"></div>
                        </div>
                        <div class="offer-box-text"><?= $home_about_us->description ?></div>
                        <a class="link" href="<?=base_url('about')?>">المذيد عنا</a>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="section">
        <div class="container">
            <div class="divider divider-xl divider-200"></div>
        </div>
    </section>


    <!-- Home Menu-->
    <section class="section section-md bg-transparent">
        <div class="container">
            <div class="row row-50">

                <?php foreach ($cars as $car) { ?>

                    <div class="col-xs-6 col-lg-4">
                        <!-- Product-->
                        <article class="product">
                            <div class="product-figure">
                                <a href="#"><img class="product-image" src="<?=base_url('').$car['image']?>" alt=""
                                                 width="169" height="169"/></a>

                            </div>
                            <div class="product-body">
                                <div class="product-title h5"><a href="#"><?= $car['title'] ?></a></div>
                                <p class="product-text"><?= substr($car['description'], 0, 100) ?></p>
                                <div class="product-price"><span><?= $car['region_name'] ?></span>
                                </div>
                            </div>
                        </article>
                    </div>

                <?php } ?>

                <div class="col-12 text-center"><a class="btn btn-lg btn-secondary" href="<?=base_url('cars')?>">العربيات</a></div>
            </div>
        </div>
    </section>


    <!-- home about 2-->
    <section class="section-md bg-transparent">
        <div class="container">
            <div class="row row-30">
                <div class="col-md-6"><img src="<?=base_url() ?>/assets/images/home-4-570x634.jpg" alt="" width="570" height="634"/>
                </div>
                <div class="col-md-6">
                    <div class="accent-box accent-box-primary context-dark"
                         style="background-image: url(<?=base_url().$why_choose_us->image?>);">
                        <h4 class="text-warning text-capitalize font-weight-normal font-cursive">لما نحن</h4>
                        <h2 class="h2-small"><?=$why_choose_us->title?></h2>
                        <p>
                            <?= $why_choose_us->description ?>
                        </p><a class="link" href="<?=base_url('about')?>">اقرأ المذيد</a>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- home testimonials-->
    <section class="section section-with-right-offset section-lg context-dark" style="background-image: url(&quot;<?=base_url('')?>/assets/images/testimonials-bg.jpg&quot;); background-repeat:round;">
        <div class="bg-image overlay-black"
             style="width: 100%"></div>
        <div class="container">
            <h2 class="section-title-with-img"><img class="mr-3" src="<?=base_url() ?>/assets/images/quote-icon.png" alt=""/>التوصيات
            </h2>
            <!-- Owl Carousel-->
            <div class="owl-carousel owl-carousel-dots-right" data-owl="{&quot;dots&quot;:true}">

                <?php foreach($testimonials as $testimonial){   ?>
                <!-- Quote simple-->
                <div class="quote quote-simple">
                    <div class="quote-text">
                        <q>
                            <?= $testimonial->message ?>
                        </q>
                    </div>
                    <div class="quote-author h6">
                        <p>-<?= $testimonial->name ?></p>
                    </div>
                </div>
                <?php } ?>

            </div>
        </div>
    </section>


    <!-- Home News-->
    <section class="section-md bg-transparent">
        <div class="container">
            <div class="row row-60">
                <div class="col-12">
                    <div class="row row-20 align-items-end">
                        <div class="col-md-7">
                            <h3 class="text-warning">ما الجديد ؟</h3>
                            <h2 class="mt-0">اخبار ومقالات</h2>
                        </div>
                        <div class="col-md-5 text-md-right"><a class="btn btn-lg btn-primary" href="<?=base_url('posts')?>">عرض المذيد من الاخبار</a></div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="row row-30">
                        <div class="col-md-6">
                            <img src="<?= base_url() . $latest_post->image ?>" alt="" width="570" height="457"/>
                        </div>
                        <div class="col-md-6">
                            <div class="accent-box bg-100"
                                 style="background-image: url(&quot;<?=base_url('')?>/assets/images/accent-box-bg-1.png&quot;);">
                                <div class="post post-minimal">
                                    <ul class="post-minimal-meta">
                                        <li>by
                                            <a href="#"><?=$this->MainModel->get_user_by_id($latest_post->author_id)->name?></a>
                                        </li>
                                        <!-- <li><a href="#"><?// $latest_post->created_at ?></a></li> -->
                                    </ul>
                                    <h4 class="post-minimal-title"><a href="#"><?= $latest_post->title ?></a></h4><a
                                            class="link" href="<?=base_url('post/').$latest_post->id?>">Read more</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-12">
                    <div class="row row-30">
                        <?php
                        foreach($latest_posts as $post)
                        {?>
                        <div class="col-md-6 col-lg-4">
                            <div class="post post-classic media align-items-center align-items-xl-start">
                                <div class="post-classic-img"><a href="<?=base_url('post/').$post->id?>"><img
                                                src="<?= site_url('/') ?>/<?= $post->image ?>" alt="" width="141"
                                                height="113"/></a></div>
                                <div class="post-classic-body media-body">
                                    <!-- <div class="post-classic-date"><?// $post->created_at ?></div> -->
                                    <h5 class="post-classic-title"><a href="<?=base_url('post/').$post->id?>"><?= $post->title ?></a></h5>
                                </div>
                            </div>
                        </div>

                        <?php }?>

                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Home subscribe-->
    <section class="section-md bg-primary bg-image context-dark"
             style="background-image: url(&quot;<?=base_url('')?>/assets/images/bg-pattern-2.png&quot;)">
        <div class="container text-center">
            <div class="row row-30 justify-content-center">
                <div class="col-sm-10 col-xl-8">
                    <h3 class="text-warning">متابعه النشره</h3>
                    <h4 class="mt-3">تابعنا</h4>
                </div>
                <div class="col-sm-8 col-xl-6">
                    <form class=" form-inline justify-content-center novi-disabled"
                          data-form-output="form-output-global" data-form-type="subscribe" method="post"
                          action="<?=base_url('newsletter/save')?>">
                        <div class="form-inline-group">
                            <input class="form-control" type="email" name="email" placeholder="الايميل"
                                   data-constraints="@Email @Required">
                        </div>
                        <button style="margin-top: 0;" class="btn btn-secondary" type="submit">اشتراك</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

<?php
//$this->load->view('front/parts/footer');

?>