<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Contact Listing</h3>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Message</th>
                    </tr>
                    <?php foreach($contacts as $p){ ?>
                        <tr>
                            <td><?php echo $p['id']; ?></td>
                            <td><?php echo $p['name']; ?></td>
                            <td><?php echo $p['email']; ?></td>
                            <td><?php echo $p['message']; ?></td>
                            <td>
                                <a href="<?php echo site_url('admin/contact/remove/'.$p['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                            </td>
                        </tr>
                    <?php } ?>
                </table>

            </div>
        </div>
    </div>
</div>
