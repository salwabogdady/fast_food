<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Permission Add</h3>
            </div>
            <?php echo form_open('permission/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="key" class="control-label">Key</label>
						<div class="form-group">
							<input type="text" name="key" value="<?php echo $this->input->post('key'); ?>" class="form-control" id="key" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="table_name" class="control-label">Table Name</label>
						<div class="form-group">
							<input type="text" name="table_name" value="<?php echo $this->input->post('table_name'); ?>" class="form-control" id="table_name" />
						</div>
					</div>

				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>