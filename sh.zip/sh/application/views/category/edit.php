<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Category Edit</h3>
            </div>
			<?php echo form_open('admin/category/edit/'.$category['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="parent_id" class="control-label"><span class="text-danger">*</span>Parent Id</label>
						<div class="form-group">
                            <select name="parent_id" class="form-control">
                                <?php foreach ($parents as $own){
                                    ?>
                                    <option <?php if($category['id']==$own->id) {echo "selected";} ?> value="<?=$own->id?>"><?=$own->name?></option>
                                <?php } ?>

                            </select>
							<span class="text-danger"><?php echo form_error('parent_id');?></span>
						</div>
					</div>
<!--					<div class="col-md-6">
						<label for="order" class="control-label"><span class="text-danger">*</span>Order</label>
						<div class="form-group">
							<input type="text" name="order" value="<?php /*echo ($this->input->post('order') ? $this->input->post('order') : $category['order']); */?>" class="form-control" id="order" />
							<span class="text-danger"><?php /*echo form_error('order');*/?></span>
						</div>
					</div>-->
					<div class="col-md-6">
						<label for="name" class="control-label"><span class="text-danger">*</span>Name</label>
						<div class="form-group">
							<input type="text" name="name" value="<?php echo ($this->input->post('name') ? $this->input->post('name') : $category['name']); ?>" class="form-control" id="name" />
							<span class="text-danger"><?php echo form_error('name');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="slug" class="control-label"><span class="text-danger">*</span>Slug</label>
						<div class="form-group">
							<input type="text" name="slug" value="<?php echo ($this->input->post('slug') ? $this->input->post('slug') : $category['slug']); ?>" class="form-control" id="slug" />
							<span class="text-danger"><?php echo form_error('slug');?></span>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>