<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Slider Add</h3>
            </div>
            <?php echo form_open_multipart('admin/slider/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="slug" class="control-label"><span class="text-danger">*</span>Slug</label>
						<div class="form-group">
							<input type="text" name="slug" value="<?php echo $this->input->post('slug'); ?>" class="form-control" id="slug" />
							<span class="text-danger"><?php echo form_error('slug');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="text_2" class="control-label"><span class="text-danger">*</span>Text 2</label>
						<div class="form-group">
							<input type="text" name="text_2" value="<?php echo $this->input->post('text_2'); ?>" class="form-control" id="text_2" />
							<span class="text-danger"><?php echo form_error('text_2');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="image" class="control-label"><span class="text-danger">*</span>Image</label>
						<div class="form-group">
							<input type="file" name="image" value="<?php echo $this->input->post('image'); ?>" class="form-control" id="image" />
							<span class="text-danger"><?php echo form_error('image');?></span>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>