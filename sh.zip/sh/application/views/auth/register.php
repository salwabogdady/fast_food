<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>cms</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.6 -->
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo site_url('resources/css/font-awesome.min.css'); ?>">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Datetimepicker -->
    <!-- Theme style -->
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="<?php echo site_url('resources/css/_all-skins.min.css'); ?>">


    <link rel="stylesheet" href="<?php echo site_url('resources/css/icheck-bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo site_url('resources/css/adminlte.min.css'); ?>">


</head>
<body class="hold-transition register-page">
<div class="register-box">
    <div class="register-logo">
        <a href="<?= base_url('') ?>"><b>لوحة التحكم</a>
    </div>

    <div class="card">
        <div class="card-body register-card-body">
            <p class="login-box-msg">تسجيل عضو جديد</p>

            <form action="<?= base_url('register/save') ?>" method="post">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="الاسم" name="name" required>
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fa fa-user"></span>
                        </div>
                    </div>
                </div>
                <div class="input-group mb-3">
                    <input type="email" class="form-control" placeholder="الايميل" name="email" required>
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fa fa-envelope"></span>
                        </div>
                    </div>
                </div>
                <div class="input-group mb-3">
                    <input type="password" class="form-control" placeholder="كلمة المرور" name="password" id="password" required>
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fa fa-lock"></span>
                        </div>
                    </div>
                </div>
                <div class="input-group mb-3">
                    <input type="password" class="form-control" placeholder="اعد كتابة كلمة المرور" name="confirm_password" required
                           id="confirm_password">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fa fa-lock"></span>
                        </div>
                    </div>
                </div>
                <div class="col-12 text-center">
                    <div class="row">
                        <!-- /.col -->
                        <div class="col-4">
                            <button type="submit" class="btn btn-primary btn-block" onclick="return Validate()">تسجيل</button>
                        </div>
                        <!-- /.col -->
                    </div>
                </div>

            </form>
        </div>
        <!-- /.form-box -->
    </div><!-- /.card -->
</div>
<script type="text/javascript">
    function Validate() {
        var password = document.getElementById("password").value;
        var confirmPassword = document.getElementById("confirm_password").value;
        if (password != confirmPassword) {
            alert("Passwords do not match.");
            return false;
        }
        return true;
    }
</script>


<script src="<?php echo site_url('resources/js/jquery-2.2.3.min.js'); ?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo site_url('resources/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo site_url('resources/js/bootstrap.bundle.min.js'); ?>"></script>
<script src="<?php echo site_url('resources/js/adminlte.min.js'); ?>"></script>
<!-- AdminLTE App -->

<!-- FastClick -->
<script src="<?php echo site_url('resources/js/fastclick.js'); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo site_url('resources/js/app.min.js'); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo site_url('resources/js/demo.js'); ?>"></script>
<!-- DatePicker -->
<script src="<?php echo site_url('resources/js/moment.js'); ?>"></script>
<script src="<?php echo site_url('resources/js/bootstrap-datetimepicker.min.js'); ?>"></script>
<script src="<?php echo site_url('resources/js/global.js'); ?>"></script>


</body>
</html>