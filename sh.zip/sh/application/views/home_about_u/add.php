<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Home About U Add</h3>
            </div>
            <?php echo form_open_multipart('home_about_u/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="title" class="control-label"><span class="text-danger">*</span>Title</label>
						<div class="form-group">
							<input type="text" name="title" value="<?php echo $this->input->post('title'); ?>" class="form-control" id="title" />
							<span class="text-danger"><?php echo form_error('title');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="image_1" class="control-label"><span class="text-danger">*</span>Image 1</label>
						<div class="form-group">
							<input type="file" name="image_1" value="<?php echo $this->input->post('image_1'); ?>" class="form-control" id="image_1" />
							<span class="text-danger"><?php echo form_error('image_1');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="image_2" class="control-label"><span class="text-danger">*</span>Image 2</label>
						<div class="form-group">
							<input type="file" name="image_2" value="<?php echo $this->input->post('image_2'); ?>" class="form-control" id="image_2" />
							<span class="text-danger"><?php echo form_error('image_2');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="description" class="control-label"><span class="text-danger">*</span>Description</label>
						<div class="form-group">
							<textarea name="description" class="form-control" id="description"><?php echo $this->input->post('description'); ?></textarea>
							<span class="text-danger"><?php echo form_error('description');?></span>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>