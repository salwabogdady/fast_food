<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Setting Edit</h3>
            </div>
			<?php echo form_open('setting/edit/'.$setting['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="key" class="control-label"><span class="text-danger">*</span>Key</label>
						<div class="form-group">
							<input type="text" name="key" value="<?php echo ($this->input->post('key') ? $this->input->post('key') : $setting['key']); ?>" class="form-control" id="key" />
							<span class="text-danger"><?php echo form_error('key');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="value" class="control-label"><span class="text-danger">*</span>Value</label>
						<div class="form-group">
							<input type="text" name="value" value="<?php echo ($this->input->post('value') ? $this->input->post('value') : $setting['value']); ?>" class="form-control" id="value" />
							<span class="text-danger"><?php echo form_error('value');?></span>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>