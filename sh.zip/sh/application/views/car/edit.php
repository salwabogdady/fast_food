<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Car Edit</h3>
            </div>
			<?php echo form_open_multipart('admin/car/edit/'.$car['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="number" class="control-label"><span class="text-danger">*</span>Number</label>
						<div class="form-group">
							<input type="text" name="number" value="<?php echo ($this->input->post('number') ? $this->input->post('number') : $car['number']); ?>" class="form-control" id="number" />
							<span class="text-danger"><?php echo form_error('number');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="owner" class="control-label"><span class="text-danger">*</span>Owner</label>
						<div class="form-group">
<!--							<input type="text" name="owner" value="--><?php //echo ($this->input->post('owner') ? $this->input->post('owner') : $car['owner']); ?><!--" class="form-control" id="owner" />-->
                            <select name="owner" class="form-control">
                                <?php foreach ($ownerDrop as $own){
                                    ?>
                                    <option <?php if($car['owner']==$own->id) {echo "selected";} ?> value="<?=$own->id?>"><?=$own->name?></option>
                                <?php } ?>

                            </select>
                            <span class="text-danger"><?php echo form_error('owner');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="region" class="control-label"><span class="text-danger">*</span>Region</label>
						<div class="form-group">
                            <select name="region" class="form-control">
                                <?php foreach ($regionDrop as $own){
                                    ?>
                                    <option <?php if($car['region']==$own->id) {echo "selected";} ?> value="<?=$own->id?>"><?=$own->name?></option>
                                <?php } ?>

                            </select>
							<span class="text-danger"><?php echo form_error('region');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="category" class="control-label"><span class="text-danger">*</span>Category</label>
						<div class="form-group">
                            <select name="category" class="form-control">
                                <?php foreach ($catDrop as $own){
                                    ?>
                                    <option <?php if($car['category']==$own->id) {echo "selected";} ?> value="<?=$own->id?>"><?=$own->name?></option>
                                <?php } ?>

                            </select>
							<span class="text-danger"><?php echo form_error('category');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="title" class="control-label"><span class="text-danger">*</span>Title</label>
						<div class="form-group">
							<input type="text" name="title" value="<?php echo ($this->input->post('title') ? $this->input->post('title') : $car['title']); ?>" class="form-control" id="title" />
							<span class="text-danger"><?php echo form_error('title');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="image" class="control-label"><span class="text-danger">*</span>Image</label>
						<div class="form-group">
                            <input type="file" name="image" value="<?php echo $this->input->post('image'); ?>" class="form-control" id="image" />
                            <span class="text-danger"><?php echo form_error('image');?></span>
						</div>
					</div>
                    <div class="col-md-6">
                        <label for="phone" class="control-label"><span class="text-danger">*</span>Phone</label>
                        <div class="form-group">
                            <input type="text" name="phone" value="<?php echo ($this->input->post('phone') ? $this->input->post('phone') : $car['phone']); ?>" class="form-control" id="phone" />
                            <span class="text-danger"><?php echo form_error('phone');?></span>
                        </div>
                    </div>

					<div class="col-md-6">
						<label for="description" class="control-label"><span class="text-danger">*</span>Description</label>
						<div class="form-group">
							<textarea name="description" class="form-control" id="description"><?php echo ($this->input->post('description') ? $this->input->post('description') : $car['description']); ?></textarea>
							<span class="text-danger"><?php echo form_error('description');?></span>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>