<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Cars Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('admin/car/add'); ?>" class="btn btn-success btn-sm">Add</a>
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>Number</th>
						<th>Owner</th>
						<th>Region</th>
						<th>Category</th>
						<th>Title</th>
						<th>Image</th>
						<th>Description</th>
						<th>Actions</th>
                    </tr>
                    <?php 
                    // var_dump($this->session);
                        foreach($cars as $c){ 
                            
                        if($this->session->role_id == 1)
                        {  
                            ?>
                            <tr>
                                <td><?php echo $c['number']; ?></td>
                                <td><?php echo $c['owner']; ?></td>
                                <td><?php echo $c['region']; ?></td>
                                <td><?php echo $c['category']; ?></td>
                                <td><?php echo $c['title']; ?></td>
                                <td><img src="<?php echo base_url().$c['image']; ?>" alt="<?php echo $c['owner']; ?>" height="100px" width="100px"></td>
                                <td><?php echo $c['description']; ?></td>
                                <td>
                                    <a href="<?php echo site_url('admin/car/edit/'.$c['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a>
                                    <a href="<?php echo site_url('admin/car/remove/'.$c['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                                </td>
                            </tr>
                            <?php
                        }else{
                        if($this->session->id == $c['owner']){

                            ?>
                            <tr>
                                <td><?php echo $c['number']; ?></td>
                                <td><?php echo $c['owner']; ?></td>
                                <td><?php echo $c['region']; ?></td>
                                <td><?php echo $c['category']; ?></td>
                                <td><?php echo $c['title']; ?></td>
                                <td><img src="<?php echo base_url().$c['image']; ?>" alt="<?php echo $c['owner']; ?>" height="100px" width="100px"></td>
                                <td><?php echo $c['description']; ?></td>
                                <td>
                                    <a href="<?php echo site_url('admin/car/edit/'.$c['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a>
                                    <a href="<?php echo site_url('admin/car/remove/'.$c['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                                </td>
                            </tr>
                        <?php
                        }
                    }
                    ?>
                   
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
