<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Why Choose Us Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('why_choose_u/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>ID</th>
						<th>Title</th>
						<th>Image</th>
						<th>Description</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($why_choose_us as $w){ ?>
                    <tr>
						<td><?php echo $w['id']; ?></td>
						<td><?php echo $w['title']; ?></td>
                        <td><img src="<?php echo base_url().$w['image']; ?>" alt="<?php echo $w['image']; ?>" height="100px" width="100px" style="border-radius: 50%;"></td>
						<td><?php echo $w['description']; ?></td>
						<td>
                            <a href="<?php echo site_url('why_choose_u/edit/'.$w['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a> 
                            <a href="<?php echo site_url('why_choose_u/remove/'.$w['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
