<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Permission Role Add</h3>
            </div>
            <?php echo form_open('admin/permission_role/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
                    <div class="col-md-6">
                        <label for="slug" class="control-label"><span class="text-danger">*</span>Roles</label>
                        <div class="form-group">
                            <select name="role_id" class="form-control">
                                <?php
                                foreach ($roles as $role){ ?>
                                    <option value="<?=$role->id?>"><?=$role->name?></option>
                                <?php }?>
                            </select>
                            <span class="text-danger"><?php echo form_error('roles');?></span>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label for="slug" class="control-label"><span class="text-danger">*</span>Perm</label>
                        <div class="form-group">
                            <select name="permission_id" class="form-control">
                                <?php
                                foreach ($perms as $perm){ ?>
                                    <option value="<?=$perm->id?>"><?=$perm->key?></option>
                                <?php }?>
                            </select>
                            <span class="text-danger"><?php echo form_error('roles');?></span>
                        </div>
                    </div>


				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>