<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Permission Role Listing</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('permission_role/add'); ?>" class="btn btn-success btn-sm">Add</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
                        <th>Role</th>
                        <th>Permission</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($permission_role as $p){ ?>
                    <tr>

                        <td><?=$this->Permission_role_model->get_role($p['role_id'])->name; ?></td>
                        <td><?=$this->Permission_role_model->get_perm($p['permission_id'])->key; ?></td>

						<td>

                            <a href="<?php echo site_url('admin/permission_role/edit/'.$p['permission_id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Edit</a>
                            <a href="<?php echo site_url('admin/permission_role/remove/'.$p['permission_id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Delete</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                                
            </div>
        </div>
    </div>
</div>
