-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 19, 2020 at 01:41 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fast_food_car`
--

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `id` int(10) UNSIGNED NOT NULL,
  `number` varchar(50) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `phone` text NOT NULL,
  `region` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `description` text CHARACTER SET utf8 DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`id`, `number`, `owner`, `phone`, `region`, `category`, `title`, `description`, `image`) VALUES
(9, '1', '1', '01028719367', '1', '5', 'Tasty', 'يسعدنا تقديم كل ماهو لذيذ لعملأنا', '/uploads/car/a44327b0aeab99abbe4f44a16b9b62f8.jpeg'),
(10, '2', '1', '015553892417', '1', '6', 'Sushi - السوشي', 'نحن مهتمون بارضاء العميل وتقديم الخدمه علي مستوي عالي من الكفاءه', '/uploads/car/fdd4aebb96ae3d89e7fa4d509a744192.jpg'),
(11, '3', '1', '01554778319', '1', '7', 'BETO drink', 'نحن في خدمه عملأنا', '/uploads/car/6f357429707bd7fc75b455f6e6adafb4.jpg'),
(12, '4', '1', '01284006911', '1', '8', 'GRILLS', 'نحن في خدمه عملأنا في اي وقت', '/uploads/car/098826c9ede946eb1a9d3ec5448f9956.jpg'),
(13, '5', '1', '01094072359', '1', '9', 'Garam Masala', 'نحن في خدمه عملانا علي مدار الساعه', '/uploads/car/afc6390e9d7f805bd65d5ac44f0998d8.jpg'),
(14, '6', '1', '01287100584', '1', '8', 'KAYA', 'متاحون 24 ساعه في خدمتكم', '/uploads/car/5e0536d72ba36e185da536d21f217f87.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `car_category`
--

CREATE TABLE `car_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `car_category`
--

INSERT INTO `car_category` (`id`, `name`) VALUES
(5, 'ايس كريم'),
(6, 'بحريات'),
(7, 'مشروبات'),
(8, 'اكلات سريعه'),
(9, 'اكلات هنديه');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(10) UNSIGNED DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `name` varchar(191) CHARACTER SET utf8 NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `order`, `name`, `slug`) VALUES
(2, NULL, 0, 'اهم الاخبار', 'اهم الاخبار'),
(5, 5, NULL, 'عروض', 'مرحبا');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `food_menus`
--

CREATE TABLE `food_menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `description` text CHARACTER SET utf8 DEFAULT NULL,
  `image` text DEFAULT NULL,
  `car` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `food_menus`
--

INSERT INTO `food_menus` (`id`, `title`, `description`, `image`, `car`) VALUES
(3, 'ايس كريم فراوله', 'ايس كريم فراوله مكونات طبيعيه طعم اصلي ', '/uploads/food_menu/db3f4dcfddb0e031e4248dfd8b700fa6.jpg', '9'),
(4, 'ايس كريم فانليا', 'ايس كريم فانليا وحليب مكونات طبيعبه 100 في 100', '/uploads/food_menu/7dfc41859d44de9ffd7222fc927d545b.jpg', '9'),
(5, 'ايس كريم شكولاته', 'ايس كريم شكولاته و حليب ومكسرات مكونات طبيعيه طعم اصلي', '/uploads/food_menu/0ba453dc8c615b8dd50a9b32aff96e07.jpg', '9'),
(6, 'رول القوس قزح', 'رول القوس قزح ', '/uploads/food_menu/e6279e904c9edcab78a3a49358932b53.jpg', '10'),
(7, 'رول السلمون والأفوكاد', 'رول السلمون والأفوكاد', '/uploads/food_menu/fcb1ec1fb91b9ac38c840a5c6a3227fd.jpg', '10'),
(8, 'رول كاليفورنيا', 'رول كاليفورنيا', '/uploads/food_menu/3552c5627ed17c808eecfd9535f54bc4.jpg', '10'),
(9, 'عصير برتقال فريش', 'عصير برتقال فريش', '/uploads/food_menu/11e57c1a3bcd87de0e485d981a120402.jpg', '11'),
(10, 'عصير فراوله فريش', 'عصير فراوله فريش', '/uploads/food_menu/aec1cd5e68b18e54b3454c6a5e9d7f08.jpg', '11'),
(11, 'عصير موز فريش', 'عصير موز فريش', '/uploads/food_menu/6d431de8b3bfd7498dd16329cecd6367.jpg', '11'),
(12, 'سجق بلدي', 'سجق بلدي ', '/uploads/food_menu/520d85f1808722dca3b0aa0ef8a18e90.jpg', '12'),
(13, 'سجق سكندراني', 'سجق سكندراني', '/uploads/food_menu/e95f69990ec90ad943d44f942089f31e.jpg', '12'),
(17, 'برياني لحم مع خضار', 'برياني لحم وخضار من انواع البرياني الهندي اللذيذ الذي يحظى بشهرة واسعة في المنطقة العربية ، و تتميز هذه الوصفة باضافة انواع متعددة من الخضار التي ستضفي نكهة مميزة على برياني لحم وخضار .', '/uploads/food_menu/74eb102300b70dfba29911e6f44adadc.jpg', '13'),
(18, '  Aloo tikkiألو تيكي ', 'طبق الألو تيكي ينتمي إلى عائلة التشات أي المقبلات المقلية التي تباع في الأكشاك ويعتبر من أشهر المقبلات في المطبخ الهندي حيث لا يخلو أي بيت أو مطعم منه. وتعني كلمة ألو البطاطس أما كلمة تيكي فتعني كروكيت (الكرات المقلية) وتصنع كرات الألو تيكي من البطاطس المهروشة التي يضاف إليها بعض التوابل كالتمر الهندي والزنجبيل والكزبرة والنعناع والحمص وتقلى في زيت ساخنة وغالباً ما تؤكل ساخنة أو دافئة.', '/uploads/food_menu/9e20c4e6c66d1251bbb160f4350c1922.jpg', '13'),
(19, '  Samosaسانبوسة ', 'تعتبر فطائر السنبوسة من بين أشهر الأكلات الهندية وقد أصبحت من أساسيات المائدة الهندية خلال القرن 13 عندما تعرف السكان عليها من خلال التجار القادمين من آسيا الوسطى. وهي عبارة عن فطائر من الدقيق محشوة بخليط من البطاطس المهروسة والبصل والبازلاء والعدس ويضاف إليها عدة توابل وتقلى في زيت ساخنة، وغالباً ما يتم أكلها مع صلصات التشاتني.', '/uploads/food_menu/e1a634ba7cbfd752c62e6bc6af362643.jpg', '13'),
(20, '   Paneer tikka بانيير تيكا', 'كلمة بانيير تعني بالهندية جبن ويعتبر البانيير تيكا من أشهر أنواع البانيير حيث يقطع الجبن إلى مكعبات ويضاف إليها العديد من البهارات والتوابل وتشوى على الفحم. ويعتبر البانيير تيكا بديلا لطبق دجاج التيكا حيث أن أكثر من 30 في المائة من الهنود نباتيون.', '/uploads/food_menu/23e065043f131f84bf14625daef411bb.jpg', '13'),
(21, '   Dahi puri داهي بوري', 'يرجع أصل هذا الطبق إلى ولاية ماهاراشترا وبالتحديد إلى مدينة مومباي، ويعتبر من بين المقبلات الأكثر شعبية في الهند. ويتكون الداهي بوري من فطائر خبز البوري الصغيرة المقلية والتي تحشى بخليط من البطاطس المهروسة والحمص المتبلة بالكركم والفلفل الحار والملح ثم يضاف تشاتني التمر الهندي والتشاتني الأخضر الحار فوقها، ويسكب اليوغرت المحلى فوق كل فطيرة وتزين بالسيف (حلوى النودلز الهندية) وحبات الرمان وأوراق الكزبرة وحبات بقلة الماش.', '/uploads/food_menu/66183c2b827684eb5689c2d32eb0c10a.jpg', '13'),
(22, '   Murgh Makhni مورغ ماخني', 'طبق المورغ مخني أو الباتر تشيكن من أشهر الأكلات الهندية حيث يقدم في أفخم المطاعم العالمية وهو عبارة عن قطع دجاج مشوية على طريقة التندور أو مقلية ومطهوة في صلصة طماطم قشدية مع توابل وبهارات وأعشاب من بينها بهار الغارام ماسالا الشهير. ويؤكل الطبق إما مع الأرز أو مع خبز النان الساخن.', '/uploads/food_menu/34739103d17cf53c87fc39466a7068f7.jpg', '13'),
(23, ' آيس كريم التوت', '  آيس كريم بالتوت بالحليب مكونات طبيعية', '/uploads/food_menu/fd5292671644c296ef1eb95f4d431740.jpg', '9'),
(24, 'كوكتيل الآيس كريم والقهوة ', ' كوكتيل الآيس كريم والقهوة  والحليب الطبيعي', '/uploads/food_menu/9e7f43c85a8128ae15298b64eedb537a.webp', '9'),
(25, 'ايس الكريم الاوريو', 'ايس الكريم الاوريو  بالحليب والفانيلا  وقطع بسكويت الاريو ', '/uploads/food_menu/9cbd9ec83c0e8dc76c962383d99442eb.jpg', '9'),
(26, ' كاليفورنيا رول', 'من شوشي رول:\r\n\r\nكاليفورنيا رول', '/uploads/food_menu/558fde7f551392ea0f1b6f6c96fb1090.jpg', '10'),
(27, ' فى اى بي سوشي رول', 'من شوشي رول:\r\n\r\nفى اى بي سوشي رول', '/uploads/food_menu/ea9318af3436bb2ec6adf607b45e3406.jpg', '10'),
(28, 'عصير الجزر', 'عصير الجزر طبيعي', '/uploads/food_menu/85e6c66985e07fdfb6da8930c8a190a0.jpg', '11'),
(29, 'عصير بوريو', 'عصير اريو ميلك  شيك بالبن', '/uploads/food_menu/402734f55308bf7d6fa35e71473e27c2.jpg', '11'),
(30, 'عصير المانجو', 'عصير المانجو الطبيعي', '/uploads/food_menu/11fc25ca4225283f8ea2b7c9661e8167.jpg', '11'),
(31, 'عصير كوكتيل', 'عصير كوكتيل منعش', '/uploads/food_menu/0204a73786be593eef9da75ccf426d40.jpeg', '11'),
(32, ' برجر اللحم المشوي', ' برجر اللحم المشوي مع البطاطس', '/uploads/food_menu/390231bcaee8673b454a04b64093a85c.jpg', '12'),
(33, 'فيليه السمك مع جبن البارميزان', 'فيليه السمك مع جبن البارميزان\r\n', '/uploads/food_menu/1df7ac7958972928d7b172c51bef50be.jpg', '10'),
(34, 'سندوتش زنجر', ' سندوتش زنجر الفراخ', '/uploads/food_menu/1f34cf52c5158dbf321aebd04de0d6ee.jpg', '12'),
(35, 'كفته', 'ساندوتش كفته', '/uploads/food_menu/883d4ed0f1c2dc4be63e1899541b6f19.jpg', '12'),
(36, ' شاورما دجاج', ' سندوتش شاورما بالدجاج', '/uploads/food_menu/0e5c4d0380748873fa6c4dc462747839.jpg', '12'),
(37, 'المشروم المقلي بالجبنة الموتزاريلا', 'المشروم المقلي بالجبنة الموتزاريلا\r\n', '/uploads/food_menu/81836a1a75b6a00304610558c2ee4d5c.jpg', '14'),
(38, 'ساندوتش شرائح الديك الرومي والبسطرمة والجبن', 'ساندوتش شرائح الديك الرومي والبسطرمة والجبن\r\n', '/uploads/food_menu/99bcaceee3dda76850a5fbebb8ac8eca.jpg', '14'),
(40, 'عيش باللحم \"حواوشي\"', 'عيش باللحم \"حواوشي\"', '/uploads/food_menu/17db3513fa989943b734e1cccf48068f.jpg', '14'),
(41, 'توست التونة', 'توست التونة', '/uploads/food_menu/492bc8d1d3b6a83642eaf5ede9f661bb.jpg', '14'),
(42, 'السوسيس والبطاطس', 'السوسيس والبطاطس\r\n', '/uploads/food_menu/41a18d875af74dc5667e12cd90ebcbcb.jpg', '14'),
(43, 'بيض عيون بالطماطم', 'بيض عيون بالطماطم', '/uploads/food_menu/2991f96f7c137c412c8befd8fce47dd4.jpg', '14'),
(44, 'ساندوتش الكبدة', 'ساندوتش الكبدة', '/uploads/food_menu/7d39c78a82ddcf98e4feb636da021d27.jpg', '14'),
(45, 'عصير جوافة بالبن', 'عصير الجوافة بالبن', '/uploads/food_menu/bdf65c2a49f6aae6d97289c5f7920b63.jpg', '11'),
(47, 'عصير الدوم', 'عصير الدوم طبيعي', '/uploads/food_menu/3b4fd3a033ea18e8574d399a46d1b873.jpg', '11'),
(48, 'عصير الكركدية', 'عصير الكركدية طبيعي', '/uploads/food_menu/f69a696210ebe14925f388b03b0f5acd.jpg', '11'),
(49, 'ميلك شيك تمر', 'ميلك شيك تمر', '/uploads/food_menu/70e6f1d38db057e6fb769ed0fa056721.jpg', '9'),
(50, 'عصير الليمون  بالريحان', 'عصير الليمون بالريحان', '/uploads/food_menu/884c16b1bc263ec3eb278d9ccd3bc728.jpg', '11'),
(51, 'االقهوة-المثلجةمع اللوز', 'االقهوة-المثلجةمع للوز', '/uploads/food_menu/cd3fcecf89584fc812741c2260cb4b70.jpg', '9'),
(52, 'سموثي القهوه بالكريمة', 'سموثي القهوه بالكريمة', '/uploads/food_menu/dbc3b6bfe64fd022b03e6631d5662eb6.jpg', '9');

-- --------------------------------------------------------

--
-- Table structure for table `home_about_us`
--

CREATE TABLE `home_about_us` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `description` text CHARACTER SET utf8 DEFAULT NULL,
  `image_1` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `image_2` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `home_about_us`
--

INSERT INTO `home_about_us` (`id`, `title`, `description`, `image_1`, `image_2`) VALUES
(6, 'خدمه 24 ساعه', 'نحن في خدمه المستهلكين في اي وقت ونعمل علي تحسن خدماتنا', '/uploads/home_about_us/a3c9cb09f6a1ab175b23efdd5c119732.jpg', '/uploads/home_about_us/5ee8871e978a60989edbe5b2ce2fcdd3.jpg'),
(7, '  Rogan Josh  روغان دجوش ', 'يرجع أصل هذا الطبق إلى بلاد فارس وقد أدخله إلى كشمير المغول الهنود وأصبحت هذه المنطقة تشتهر به عالمياً، ويعتبر روغان دجوش من الأكلات الهندية الرائعة حيث يستعمل في إعداده لحم الضان أو الماعز مطهو في مرق مع الزنجبيل والثوم وبعض التوابل كالقرفة والهال والقرنفل ويمكن إضافة البصل واليوغرت ويستمد الطبق لونه الأحمر الداكن من الفلفل الكاشميري الحار', '/uploads/home_about_us/bda64ca538c923432bd9d9498228c1b9.jpg', '/uploads/home_about_us/5c1fc2280185b85c0d869284af4ea007.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `newsletters`
--

CREATE TABLE `newsletters` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newsletters`
--

INSERT INTO `newsletters` (`id`, `email`) VALUES
(1, 'asd,asdjkasd'),
(2, 'omar.abulkhair@outlook.com'),
(3, 'omar.abulkhair@outlook.com'),
(4, 'omar.abulkhair@outlook.com'),
(5, 'omar.abulkhair@outlook.com'),
(6, 'omar.asdklajs@kljaskld.com');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(191) NOT NULL,
  `table_name` varchar(191) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `key`, `table_name`, `created_at`, `updated_at`) VALUES
(1, 'car', 'cars', '2020-02-15 20:58:56', '2020-02-15 20:58:56'),
(2, 'car_category', 'car_category', '2020-02-15 22:04:13', '2020-02-15 22:04:13'),
(3, 'category', 'category', '2020-02-15 22:54:18', '2020-02-15 22:54:18'),
(4, 'food_menu', NULL, '2020-02-15 22:55:09', '0000-00-00 00:00:00'),
(5, 'home_about', NULL, '2020-02-15 22:55:24', '0000-00-00 00:00:00'),
(6, 'newsletter', NULL, '2020-02-15 22:55:32', '0000-00-00 00:00:00'),
(7, 'permission', NULL, '2020-02-15 22:56:12', '0000-00-00 00:00:00'),
(8, 'permission_role', NULL, '2020-02-15 23:04:39', '0000-00-00 00:00:00'),
(9, 'post', NULL, '2020-02-15 22:56:06', '0000-00-00 00:00:00'),
(10, 'region', NULL, '2020-02-15 22:56:19', '0000-00-00 00:00:00'),
(11, 'role', NULL, '2020-02-15 22:56:28', '0000-00-00 00:00:00'),
(12, 'slider', NULL, '2020-02-15 22:56:32', '0000-00-00 00:00:00'),
(13, 'testimonial', NULL, '2020-02-15 22:56:43', '0000-00-00 00:00:00'),
(14, 'user', NULL, '2020-02-15 22:56:47', '0000-00-00 00:00:00'),
(15, 'why_choose_us', NULL, '2020-02-15 22:56:54', '0000-00-00 00:00:00'),
(16, 'setting', NULL, '2020-02-15 22:56:56', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `author_id` int(11) NOT NULL DEFAULT 1,
  `category_id` int(11) DEFAULT NULL,
  `title` varchar(191) CHARACTER SET utf8 NOT NULL,
  `seo_title` varchar(191) CHARACTER SET utf8 DEFAULT NULL,
  `excerpt` text CHARACTER SET utf8 DEFAULT NULL,
  `body` text CHARACTER SET utf8 NOT NULL,
  `image` varchar(191) CHARACTER SET utf8 DEFAULT NULL,
  `slug` varchar(191) CHARACTER SET utf8 NOT NULL,
  `meta_description` text CHARACTER SET utf8 DEFAULT NULL,
  `meta_keywords` text CHARACTER SET utf8 DEFAULT NULL,
  `status` enum('PUBLISHED','DRAFT','PENDING') NOT NULL,
  `featured` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `author_id`, `category_id`, `title`, `seo_title`, `excerpt`, `body`, `image`, `slug`, `meta_description`, `meta_keywords`, `status`, `featured`) VALUES
(8, 5, 2, 'الفطيرة الايطالية ', 'فطائر', 'فطيرة الايطالية', 'المكونات: 3 كوب و 1/2 دقيق. 3/4 كوب ماء فاتر. 1 ملعقة صغيرة ملح. 1 ملعقة كبيرة حليب بودر. 2 ملعقة كبيرة سكر. 3 ملعقة زيت. \r\nمقادير الحشوة: 1/2 كجم صدور دجاج. 1 كوب فطر. 1 كوب جبنة موزاريلا. 2 حبة فلفل رومي. 1 بصلة. 1/4 كوب كريمة طبخ. الطريقة: ضعي البصلة على النار مع القليل من الزيت، وقومي بعد ذلك بتركها حتى يصبح لونها ذهبي، وضعي الفلفل الرومي، وقلبي جيد جدًا. أضيفي الفطر إلى البصل، والفلفل. قومي بعد ذلك بإضافة الدجاج، وقومي بالتقليب الجيد، وضعي الملح، والبهارات، وذلك حسب رغبتك. اتركِ على نار هادئة حتى النضج. أضيفي كريمة الطبخ إلى المزيج، وتستطيعي تحضير كريمة طبخ في البيت، إنه عبارة عن 1 ملعقة حليب، و1 ملعقة نشا، وكوب ماء، وضعيهم على النار إلى أن يتجانسوا جيدًا، وأصصيفي بعد ذلك الملح، وأضيفي علبة القشدة حسب رغبتك. قبل عملية النضج فإن الخليط يصبح متجانسًا مثل الكريمة والدجاج، وقومي بتحضير العجين. ضعي المكونات الجافة مع بعضها البعض على الدقيق، وقومي بخفق البيض مع الزيت، وضعي على الدقيق بعض من الماء، وقومي بالعجن الجيد. اتركِ العجينة لمدة 10 دقيقة كاملة، وقومي بعد ذلك بتقطيع العجين إلى دوائر كبيرة، وقومي بعد ذلك بحشوها على كل جانب من الجوانب، وضعي الشرائح عليها، وقومي بتشريح من الجانب، ويتم اغلاقه على الجزء الأول. قومي بدهن الفطيرة بصفار البيضة، ورشي عليها السمسم أو حبة البركة حسب رغبتك.\r\n', '/uploads/post/d542a2cba75fc5fb0d703c06b181ce43.webp', 'فطائر', 'فطائر', 'فطائر', 'PUBLISHED', 0),
(9, 2, 2, '   Kulfi كولفي', 'صيني', 'كولفي', 'تعتبر مثلجات الكولفي من الأكلات الشهيرة في الهند حيث ذاع صيتها خارج حدود البلاد، ويمكن إعدادها بعدة نكهات كالورد والمانغو والهال والزعفران وغالبا ما تحتوي على حبات الفستق', '/uploads/post/3d606c97e0e49a7356c7bec204ad40b5.jpg', 'مقبلات', 'كولفي', 'كولفي صيني', 'PUBLISHED', 0),
(10, 5, 5, '   Chai Masala شاي كرك', 'شاي كرك', 'شاي كرك', 'يسمى بشاي كرك أو ماسالا تشاي وهو عبارة عن شاي أسود معد مع بعض التوابل والأعشاب الهندية ويضاف الحليب والزنجبيل والهال والسكر إلى الخليط وتختلف البهارات والأعشاب من منطقة إلى أخرى حيث تضاف القرفة والينسون وجوز الطيب وغيرها من التوابل', '/uploads/post/6ae0679f20d978a67f1d6bda0fb6e97c.jpg', 'مشروبات', 'شاي كرك', 'شاي كرك صيني', 'PUBLISHED', 0),
(11, 5, 2, '   Lassi لاسي', 'لاسي صيني', 'لاسي', 'يعتبر مشروب اللاسي من أشهر المشروبات الباردة في الهند ويحضر بتخمير اللبن وإضافة السكر وماء الورد والليمون والفواكه ويشتهر أكثر في منطقة راجستان بالهند وكذلك عند السند في باكستان. ويعتبر مشروب اللاسي بالمانغو أشهر أنواع اللاسي حيث يباع في كل أرجاء العالم', '/uploads/post/9d9d5549c2fd45ec8e38808b5c169dbb.jpg', 'مشروبات', 'لاسي', 'لاسي', 'PUBLISHED', 0),
(12, 5, 5, '   Kheer كيير', ' كيير شوربة ', 'كيير', 'من أشهر أنواع الأرز بالحليب ويعتبر من أطيب الأكلات الهندية حيث يحتوي على الأرز والبرغل والتابيوكا أو الشعرية والحليب والسكر ويطهى الكل ثم يضاف إلى الخليط حبات الكاجو والهيل واللوز والفستق والزعفران', '/uploads/post/deba6f998f3b9a9acad51aed36a6cd92.jpg', 'شوربة', 'شوربة', 'شوربة', 'PUBLISHED', 0),
(13, 5, 2, '  Gulab Jamun غولاب دجامون', 'غولاب ', 'غولاب دجامون', 'تعتبر حلويات الغولاب دجامون من أشهر وأطيب الحلويات في الهند ويرجع أصلها إلى المناطق الشمالية حيث يقال أن طباخ الإمبراطور المغولي شاه دجاهان قد أعدها عن طريق الخطأ، والحلويات عبارة عن كويرات مصنوعة من عجينة خويا (الحليب المبخر) التي يضاف إليها القليل من الطحين والتي تقلى في الزيت تم يصب عليها شراب مصنوع من ماء الورد وحب الهال والزعفران', '/uploads/post/47c11144057997d2acc5f040fa532126.jpg', 'حلويات', 'غولاب دجامون', 'غولاب دجامون', 'PUBLISHED', 0),
(14, 5, 2, '   Meen Moilee  مين مولي', 'مين مولي هندية', 'مين مولي', 'طبق المين مولي من أشهر أكلات السمك في الهند ويرجع أصله إلى منطقة كيرلا الواقعة على الساحل الجنوبي لشبه القارة الهندية ويتميز المطبخ المحلي باستعمال الأسماك بكثرة وكذلك جوز الهند. ويعتبر طبق المين مولي من أشهر الأطباق في المنطقة وكل الهند ويستعمل سمك البومفريت الشهير والعديد من البهارات مثل أوراق الكاري والكركم والكزبرة والفلفل الأخضر الحار وتضاف أوراق الموز والبصل وحليب جوز الهند وغالباً ما يرافق المين مولي طبق من أرز الباسماتي', '/uploads/post/23fe10ae5b34fe05d5acf31716b6e7fe.jpg', 'شوربة', 'مين مولي', 'مين مولي', 'PUBLISHED', 0),
(15, 5, 2, 'حساء الدجاج', 'مصري', 'حساء الدجاج', 'وصف القائمة:\r\nواحدة من أكثر القوائم غرابة ولذيذة ، من أفضل قائمة في القارة الآسيوية سيئة السمعة ، يمكنك تجربة هذا الطبق الجميل في أي مناسبة إذا كنت لا تشعر بمظهر المطعم ، فإن ما يهم هو أنك تستمتع ما تدفعه وتمتع ببقية أمسيتك تفكر في مدى روعة هذا الطبق ، والأهم من ذلك أنصح جميع أصدقائك وعائلاتك بالانضمام إلى حفلة رائعة.\r\n\r\nبعض الاقتباسات الشهيرة لبعض الشخصيات المشهورة لها العديد من التعبيرات عن الطعام.\r\n\r\n\"كل ما تحتاجه هو الحب. لكن القليل من الشوكولاتة بين الحين والآخر لا تؤذي \". - تشارلز م.شولز\r\n\"بعد عشاء جيد يمكن للمرء أن يغفر لأي شخص ، حتى العلاقات الخاصة به.\" - أوسكار وايلد\r\n\"لا شيء أفضل من العودة إلى المنزل وتناول الطعام الجيد والاسترخاء.\" - إيرينا شايك\r\nقد يعجبك ايضا\r\nغذائية\r\nالسعرات الحرارية: 54\r\nالكوليسترول: 8 جم\r\nالألياف: 5 جم\r\nصوديوم: 65 جم\r\nالكربوهيدرات: 30 جم\r\nالدهون: 67 غ\r\nالبروتين: 500 غ\r\nحجم الجزء\r\n50 غ\r\n350 مل\r\n25 بوصة\r\n', '/uploads/post/28fb1e354236b9929b852283ba793673.jpeg', 'وجبة', 'حساء الدجاج', 'حساء الدجاج', 'PUBLISHED', 0),
(16, 5, 5, 'ذرة بوريتو الايطالية', 'سوري', 'ذرة بوريتو الايطالية', 'وصف القائمة:\r\nواحدة من أكثر القوائم غرابة ولذيذة ، من أفضل قائمة في القارة الآسيوية سيئة السمعة ، يمكنك تجربة هذا الطبق الجميل في أي مناسبة إذا كنت لا تشعر بمظهر المطعم ، فإن ما يهم هو أنك تستمتع ما تدفعه وتمتع ببقية أمسيتك تفكر في مدى روعة هذا الطبق ، والأهم من ذلك أنصح جميع أصدقائك وعائلاتك بالانضمام إلى حفلة رائعة.\r\n\r\nبعض الاقتباسات الشهيرة لبعض الشخصيات المشهورة لها العديد من التعبيرات عن الطعام.\r\n\r\n\"كل ما تحتاجه هو الحب. لكن القليل من الشوكولاتة بين الحين والآخر لا تؤذي \". - تشارلز م.شولز\r\n\"بعد عشاء جيد يمكن للمرء أن يغفر لأي شخص ، حتى العلاقات الخاصة به.\" - أوسكار وايلد\r\n\"لا شيء أفضل من العودة إلى المنزل وتناول الطعام الجيد والاسترخاء.\" - إيرينا شايك\r\n\r\nغذائية\r\nالسعرات الحرارية: 10 جم\r\nالكوليسترول: 15 جم\r\nالألياف: 20 جم\r\nصوديوم: 25 جم\r\nالكربوهيدرات: 0 ملغ\r\nالدهون: 30 جم\r\nالبروتين: 0 ملغ\r\nحجم الجزء\r\n25 جرام\r\n250 مل\r\n12 إنش', '/uploads/post/12fdf74543a5973a1b16fff99494d47b.jpg', 'اكله', 'ذرة بوريتو الايطالية', 'ذرة بوريتو الايطالية', 'PUBLISHED', 0);

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

CREATE TABLE `regions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `description` text CHARACTER SET utf8 DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `regions`
--

INSERT INTO `regions` (`id`, `name`, `description`, `created_by`) VALUES
(1, 'st 306', 'st 306', 1);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `display_name` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`) VALUES
(1, 'admin', 'ADMIN'),
(2, 'car-owner', 'Car Owner');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(255) NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `key`, `value`) VALUES
(1, 'address', 'بلبيس'),
(2, 'phone', '01553019453'),
(3, 'email', 'salwaelboghdady7@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `text_2` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `slug`, `text_2`, `image`) VALUES
(3, 'مرحبا', 'شارع 306', '/uploads/slider/bef9bd8f686c7568ca99712b35b95399.jpeg'),
(4, 'مرحبا', '306 Street', '/uploads/slider/e4538c7558fc969ce0468af9d020e075.jpg'),
(5, 'Welcome', 'شارع 306', '/uploads/slider/a5ce6e4b148b276d6b564fdd3288934e.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(10) UNSIGNED NOT NULL,
  `message` text DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `message`, `name`) VALUES
(1, 'message', 'name'),
(2, 'i love this site i always bout from this site', 'shehab osama'),
(3, 'hello i admin in this site', 'salwa elbgdady');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `avatar` varchar(191) DEFAULT NULL,
  `password` varchar(191) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `settings` text DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `name`, `email`, `avatar`, `password`, `remember_token`, `settings`, `active`) VALUES
(1, 1, 'Admin', 'admin@admin.com', '/uploads/user/036837181e8bc8fccfed0fd5574f1826.jpg', '28b192a5be36181433c9a5d1ca32ba1df5147e84', NULL, NULL, 1),
(2, 1, 'oMar', 'admin1@admin.com', '/uploads/user/b64676ed815b301b195548f0692aadbd.jpg', 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', NULL, NULL, 1),
(3, 2, 'test', 'admin@example.com', NULL, 'c629e11f8b537447a91bdce787c38f8c12e28664', NULL, NULL, 1),
(4, 2, 'abdall', 'azoghpar12@gmail.com', NULL, '8105358839b0076dffee1af97da08e7667a6e7ef', NULL, NULL, 1),
(5, 1, 'salwa', 'salwa@salwa.com', NULL, 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', NULL, NULL, 1),
(6, 2, 'shehab', 'shehab@shehab.com', '/uploads/user/ef6b5900db814bf251b05c5b9724d71e.png', 'c1bb9665cedba25a31c3ad84fb093f73febdc3dc', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `why_choose_us`
--

CREATE TABLE `why_choose_us` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `why_choose_us`
--

INSERT INTO `why_choose_us` (`id`, `title`, `description`, `image`) VALUES
(2, 'who we are?', 'we are student in obur instituation we are learn the modern tachnology to implement it to help people', '/uploads/why_us/057bc00dd40af7e49d3cc5627c9b4766.jpeg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `car_category`
--
ALTER TABLE `car_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `food_menus`
--
ALTER TABLE `food_menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home_about_us`
--
ALTER TABLE `home_about_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsletters`
--
ALTER TABLE `newsletters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `why_choose_us`
--
ALTER TABLE `why_choose_us`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `car_category`
--
ALTER TABLE `car_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `food_menus`
--
ALTER TABLE `food_menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `home_about_us`
--
ALTER TABLE `home_about_us`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `newsletters`
--
ALTER TABLE `newsletters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `regions`
--
ALTER TABLE `regions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_roles`
--
ALTER TABLE `user_roles`
  MODIFY `role_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `why_choose_us`
--
ALTER TABLE `why_choose_us`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
